# Sistema de Mudança de Imobiliária — versão para hospedagem própria

Mesmo sistema que rodava no claude.ai, com **servidor próprio** (Node.js, nada para instalar).
Ele faz o papel do banco de dados e do login.

## O que ele faz
- Formulário com busca de corretor (nome ou CNPJ/CPF), imobiliária atual automática, nova imobiliária e solicitante.
- **Quem aprova é decidido pela planilha:** troca dentro de uma equipe → só o gerente dela; troca entre as equipes do Felipe e do Anderson → **os dois**; corretor sem equipe → **Informativo** (sem aprovação).
- Painel com colunas **Aprovação Felipe** e **Aprovação Anderson**, filtros (texto, status, datas) e **cancelamento**.
- **Entrada pelo final do e-mail:** a pessoa digita o e-mail e entra se terminar com `@victa.eng.br` ou `@diagonalinc.com.br`. Nada de senha, código ou confirmação.
- Avisos por WhatsApp semi-automáticos (o botão abre o WhatsApp com a mensagem pronta; a pessoa aperta Enviar).
- Auditoria dentro do arquivo de dados: quem solicitou, aprovou ou cancelou, com e-mail e horário. As entradas (logins) ficam só no registro do servidor.

## ⚠️ Leia: o que a entrada só pelo e-mail NÃO protege
No modo padrão (`AUTH_MODE=email`) o sistema **não confirma** que a pessoa é dona do e-mail digitado. Isso significa que:
- **Qualquer pessoa que tenha o endereço do sistema** e digite um e-mail terminado em `@victa.eng.br` ou `@diagonalinc.com.br` entra. O endereço passa a ser a única barreira: não o divulgue fora da equipe.
- **Qualquer pessoa pode digitar `felipearaujo@victa.eng.br` ou `andersonvital@victa.eng.br` e aprovar no lugar deles.** O sistema só reconhece o aprovador pelo e-mail digitado.
- O painel mostra o e-mail digitado como "quem solicitou/aprovou"; ele pode não ser a pessoa real.

Isso foi uma escolha consciente para simplificar o acesso. Se um dia quiser proteger as aprovações, mude para `AUTH_MODE=microsoft` (veja o final deste arquivo) sem mexer no resto.

## Onde guardar as solicitações
O sistema guarda tudo em **um arquivo JSON** (solicitações e auditoria). Há duas formas:
- **Arquivo local** (padrão): precisa de **disco que não apague ao reiniciar**. Muitas hospedagens gratuitas apagam o disco, e as solicitações sumiriam sem aviso. Se usar essa opção, confirme isso no plano.
- **Repositório privado do GitHub** (gratuito, nada se perde): o sistema grava o arquivo lá a cada alteração. Veja "Hospedagem gratuita com dados no GitHub".

## Colocar no ar (hospedagem própria)
- **Servidor/VPS:** copie a pasta e rode `node server.js` (use `systemd` ou `pm2` para manter ligado), com Caddy ou nginx na frente para o HTTPS.
- **Azure App Service (Linux, Node 20):** envie a pasta e defina `DATA_DIR=/home/dados` (a pasta `/home` é persistente).
- **Docker:** `docker build -t sistema-mudanca .` e `docker run -d -p 3000:3000 -v dados:/dados sistema-mudanca`.
- **No seu computador (só para ver):** instale o Node.js e dê duplo clique em `iniciar.bat`. Só funciona na sua máquina.
- Defina `BASE_URL` com o endereço final (é usado nos links de WhatsApp).

## Hospedagem gratuita com dados no GitHub
Serve para qualquer hospedagem gratuita que rode Node.js. O exemplo usa o **Render**; confirme no site dele os limites atuais do plano gratuito, que mudam, e note que os nomes dos menus podem estar um pouco diferentes.

**1. Repositório só para os dados (privado).** No GitHub: *New repository*, nome `MUDAIMOB-dados`, **Private**, e marque **Add a README file** (isso cria o ramo `main`). **Não** use o mesmo repositório do código: cada gravação criaria uma alteração nele e a hospedagem reiniciaria o sistema a cada solicitação.

**2. Token de acesso.** GitHub → foto do perfil → *Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token*.
- *Repository access:* **Only select repositories** → escolha `MUDAIMOB-dados`.
- *Permissions → Repository permissions → Contents:* **Read and write**.
- Escolha a validade mais longa permitida e **copie o token** (ele aparece uma vez). **Anote a data de validade: quando o token expirar, o sistema para de gravar e precisa de um token novo.**

**3. Criar o serviço no Render.** *New → Web Service* → conecte o repositório do **código** (o `MUDAIMOB`).
- *Runtime:* Node. *Build Command:* deixe vazio ou `echo ok`. *Start Command:* `node server.js`. *Instance Type:* Free.
- Em *Environment*, crie:

| Nome | Valor |
|---|---|
| `AUTH_MODE` | `email` |
| `GITHUB_TOKEN` | o token do passo 2 |
| `GITHUB_REPO` | `seu-usuario/MUDAIMOB-dados` |
| `GITHUB_BRANCH` | `main` |
| `SESSION_SECRET` | um texto aleatório com 32+ caracteres (sem ele, as pessoas precisam entrar de novo a cada vez que o serviço reinicia) |
| `BASE_URL` | o endereço que o Render mostrar (`https://….onrender.com`), sem barra no final |

O endereço só aparece depois de criar o serviço: crie com um valor provisório em `BASE_URL`, copie o endereço real e atualize.

**4. Conferir.** Abra o endereço, entre com um e-mail da empresa e faça uma solicitação de teste. No repositório `MUDAIMOB-dados` deve aparecer o arquivo `solicitacoes.json`. Se o serviço não subir, o registro (*Logs*) dirá o motivo, por exemplo "o repositório não foi encontrado" ou "o GITHUB_TOKEN é inválido ou expirou".

**Limites desse modo:**
- O plano gratuito costuma **dormir** quando fica parado: a primeira abertura depois de um tempo pode demorar.
- Cada alteração é uma gravação no GitHub (cerca de meio segundo).
- O arquivo cresce com o tempo (cerca de 1 KB por solicitação); para o volume de uma imobiliária dura anos.
- Se o GitHub estiver fora do ar, o sistema mostra erro em vez de fingir que gravou.
- Use **uma única cópia** do servidor.
- Os dados ficam no GitHub como texto: mantenha o repositório de dados **privado** e dê acesso só a quem administra.

## Testar
`node teste-rapido.js` roda 35 verificações das regras (entrada por e-mail, aprovação por equipe, travas, cancelamento, auditoria). `node teste-github.js` roda 9 verificações do armazenamento no GitHub com um GitHub falso: gravação, reinício sem disco, conflito de versão e falha. Nenhum dos dois usa a internet nem mexe nos seus dados.

## Arquivos que você edita
- `config.json`: e-mails dos aprovadores, WhatsApp de cada pessoa, domínios permitidos e administradores.
- `data/base.json`: corretores, imobiliárias e equipes. Para atualizar a partir de uma planilha: `python3 atualizar-base.py planilha.xlsx` e reinicie.
- `data/solicitacoes.json` (ou o arquivo no repositório de dados): as solicitações **e a auditoria**. Faça backup.

## Cuidados
- Mantenha o repositório do GitHub **privado**: `base.json` tem CPFs/CNPJs e `config.json` tem e-mails e WhatsApp.
- Funciona com **uma única cópia do servidor** (dados em arquivo).
- Quem administra o servidor consegue ler e alterar os arquivos de dados.
- Não há limitação de tentativas de acesso.
- Os números de WhatsApp ficam em `config.json` e são enviados a qualquer pessoa que entre.

## Se um dia quiser proteger as aprovações (modo Microsoft, opcional)
Defina `AUTH_MODE=microsoft` e as variáveis `MS_CLIENT_ID`, `MS_CLIENT_SECRET`, `VICTA_TENANT_ID` (e `DIAGONAL_TENANT_ID`, se a Diagonal usar Microsoft 365) e `SESSION_SECRET` com 32+ caracteres. Isso exige um registro de aplicativo no Microsoft Entra ID:
1. entra.microsoft.com → *Aplicativos → Registros de aplicativo → Novo registro*, com contas de *qualquer diretório organizacional (multilocatário)*.
2. URI de redirecionamento (tipo *Web*): `BASE_URL/auth/callback`.
3. Crie um segredo do cliente e copie o valor.
Nesse modo, só quem comprova a conta Microsoft entra, e as aprovações só valem para a conta real do Felipe e do Anderson. O código dessa parte foi verificado com tokens de teste, mas não contra a Microsoft de verdade; teste no primeiro uso.
