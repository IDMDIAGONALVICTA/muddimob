'use strict';
/* Testa o armazenamento no GitHub usando um GitHub falso (não usa a internet nem o seu token). Uso: node teste-github.js */
const http = require('node:http');
let falhas = 0, total = 0;
const ok = (c, n) => { total++; if (!c) { falhas++; console.log('  FALHOU:', n); } else console.log('  ok:', n); };

/* GitHub falso: guarda um arquivo, exige o sha certo para atualizar e pode simular conflito */
const arquivo = { conteudo: null, sha: null, puts: 0, forcarConflito: 0, autorizacoes: [] };
const falso = http.createServer((req, res) => {
  let corpo = ''; req.on('data', (c) => (corpo += c)); req.on('end', () => {
    arquivo.autorizacoes.push(req.headers.authorization);
    const j = (cod, o) => { res.statusCode = cod; res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify(o)); };
    if (req.url === '/repos/dono/dados') return j(200, { full_name: 'dono/dados' });
    if (!/^\/repos\/dono\/dados\/contents\/solicitacoes\.json/.test(req.url)) return j(404, {});
    if (req.method === 'GET') return arquivo.conteudo === null ? j(404, { message: 'Not Found' }) : j(200, { sha: arquivo.sha, content: arquivo.conteudo, encoding: 'base64' });
    if (req.method === 'PUT') {
      arquivo.puts++;
      const b = JSON.parse(corpo);
      if (arquivo.forcarConflito > 0) { arquivo.forcarConflito--; arquivo.sha = 'externo' + arquivo.puts; return j(409, {}); }
      if (arquivo.conteudo !== null && b.sha !== arquivo.sha) return j(422, {});
      arquivo.conteudo = b.content; arquivo.sha = 'sha' + arquivo.puts;
      return j(200, { content: { sha: arquivo.sha } });
    }
    j(405, {});
  });
});

(async () => {
  await new Promise((r) => falso.listen(0, r));
  const os = require('node:os'), fs = require('node:fs'), path = require('node:path');
  process.env.GITHUB_TOKEN = 'token-de-teste'; process.env.GITHUB_REPO = 'dono/dados';
  process.env.GITHUB_API_URL = 'http://localhost:' + falso.address().port;
  process.env.AUTH_MODE = 'email'; process.env.BASE_URL = 'http://localhost:3999';
  process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'smg-'));
  const base = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'base.json'), 'utf8'));
  const c = base.corretores.find((x) => x.g === 'FELIPE FREIRE' && x.i === 'CANAL IMOB - GABRIELA SANTOS');
  const { criarServidor } = require('./server.js');

  async function subir() { const s = await criarServidor(); await new Promise((r) => s.listen(0, r)); return { s, url: 'http://localhost:' + s.address().port }; }
  async function entrar(url, email) {
    const r = await fetch(url + '/entrar', { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ email }) });
    return (r.headers.get('set-cookie') || '').split(';')[0];
  }
  async function chamar(url, ck, m, rota, corpo) {
    const r = await fetch(url + rota, { method: m, headers: { Cookie: ck, ...(corpo ? { 'Content-Type': 'application/json' } : {}) }, body: corpo ? JSON.stringify(corpo) : undefined });
    return { s: r.status, j: await r.json().catch(() => null) };
  }

  console.log('Armazenamento no GitHub');
  let A = await subir();
  const ana = await entrar(A.url, 'ana@victa.eng.br');
  ok((await chamar(A.url, ana, 'GET', '/api/solicitacoes')).j.length === 0, 'repositório vazio: começa sem solicitações');
  let r = await chamar(A.url, ana, 'POST', '/api/solicitacoes', { documento: c.d, nova: 'CANAL IMOB - ANDRESSA DA LUZ', solicitante: 'Ana Souza' });
  ok(r.s === 201 && arquivo.puts === 1, 'solicitação é gravada no GitHub');
  ok(arquivo.autorizacoes.every((a) => a === 'Bearer token-de-teste'), 'o token é enviado só no cabeçalho de autorização');
  const dadosRemotos = JSON.parse(Buffer.from(arquivo.conteudo, 'base64').toString());
  ok(dadosRemotos.solicitacoes.length === 1 && dadosRemotos.auditoria.length === 1, 'dados e auditoria vão juntos no mesmo arquivo');

  console.log('Reinício do servidor (disco apagado)');
  A.s.close();
  fs.rmSync(process.env.DATA_DIR, { recursive: true, force: true }); fs.mkdirSync(process.env.DATA_DIR);
  A = await subir();
  const ana2 = await entrar(A.url, 'ana@victa.eng.br');
  const lista = (await chamar(A.url, ana2, 'GET', '/api/solicitacoes')).j;
  ok(lista.length === 1 && lista[0].corretor === c.n, 'após reiniciar sem disco, a solicitação continua lá');

  console.log('Aprovações e conflitos');
  const felipe = await entrar(A.url, 'felipearaujo@victa.eng.br'), anderson = await entrar(A.url, 'andersonvital@victa.eng.br');
  await chamar(A.url, felipe, 'POST', `/api/solicitacoes/${lista[0].id}/decisao`, { decisao: 'Aprovado' });
  arquivo.forcarConflito = 1; /* alguém mexeu no arquivo por fora: o servidor deve se recuperar */
  r = await chamar(A.url, anderson, 'POST', `/api/solicitacoes/${lista[0].id}/decisao`, { decisao: 'Aprovado' });
  ok(r.s === 200 && r.j.status === 'Aprovado', 'conflito de versão é resolvido e a aprovação é gravada');
  const final = JSON.parse(Buffer.from(arquivo.conteudo, 'base64').toString());
  ok(Object.keys(final.solicitacoes[0].aprovacoes).length === 2, 'as duas aprovações estão no GitHub');

  console.log('Falha ao gravar');
  falso.close(); /* GitHub "fora do ar" */
  r = await chamar(A.url, ana2, 'POST', '/api/solicitacoes', { documento: base.corretores.find((x) => x.g === 'SEM EQUIPE').d, nova: 'CANAL IMOB - MIRELLY PINHEIRO', solicitante: 'Ana Souza' });
  ok(r.s === 503, 'se o GitHub não responder, o usuário recebe erro (e não um falso sucesso)');
  ok((await chamar(A.url, ana2, 'GET', '/api/solicitacoes')).j.length === 1, 'a solicitação que não foi gravada não aparece na lista');
  A.s.close();
  console.log(`\n${total - falhas}/${total} testes passaram.`);
  process.exit(falhas ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
