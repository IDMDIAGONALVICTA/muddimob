(function () {
  var erro = new URLSearchParams(location.search).get("erro");
  if (!erro) return;
  var e = document.getElementById("erro");
  e.textContent = erro === "email" ? "Esse e-mail não é aceito. Use um e-mail terminado em @victa.eng.br ou @diagonalinc.com.br."
    : "Não foi possível entrar. Tente novamente.";
  e.classList.remove("hidden");
})();
