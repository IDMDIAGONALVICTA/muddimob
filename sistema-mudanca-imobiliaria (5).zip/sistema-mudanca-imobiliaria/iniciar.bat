@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo O Node.js nao esta instalado. Baixe em https://nodejs.org e execute este arquivo de novo.
  pause
  exit /b
)
start "" http://localhost:3000
node server.js
pause
